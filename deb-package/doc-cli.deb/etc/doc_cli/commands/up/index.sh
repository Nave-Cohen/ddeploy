#!/bin/bash
NAME=$(basename "$WORKDIR")
if [[ $1 == "on" ]]; then
    if [[ $# -lt 2 ]]; then
        echo "[ERROR] - doc up [off/on] [github token]"
        exit 1
    fi
    if ! grep -q "$WORKDIR" /etc/doc_cli/configs/rebuild.txt; then
        echo "$WORKDIR|$2" >> /etc/doc_cli/configs/rebuild.txt
    fi
    echo "Auto rebuild for $NAME is on"
    exit 0
fi

if [[ $1 == "off" ]]; then
    grep -v "$WORKDIR" /etc/doc_cli/configs/rebuild.txt > /etc/doc_cli/configs/rebuild.tmp
    mv /etc/doc_cli/configs/rebuild.tmp /etc/doc_cli/configs/rebuild.txt

    echo "Auto rebuild for $NAME is off"
    exit 0
fi

if [[ $1 == "list" ]]; then
    file_list="/etc/doc_cli/configs/rebuild.txt"
    
    while IFS= read -r line; do
        folder=$(basename "$line")
        echo "$folder"
    done < "$file_list"
    
    exit 0
fi

if [ $# -lt 1 ]; then
command docker compose build --build-arg GIT="$GIT"
command docker compose up -d
else
    echo ./_help
fi