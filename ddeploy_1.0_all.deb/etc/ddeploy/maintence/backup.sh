base="/etc/ddeploy"

create_backup() {
    local name=$(basename "$1")
    local container="mysql-$name"
    local MYSQL_PWD="$(cat $1/.ddeploy.env | grep MYSQL_PASSWORD= | cut -d'=' -f2)"
    local output_path="$base/backups/$name/init.sql"

    # Find and backup specific files and directories inside the volume
    docker exec $container sh -c "exec mysqldump --all-databases -uroot -p$MYSQL_PWD" >"$output_path"

}

folder="$1"
create_backup "$folder"
