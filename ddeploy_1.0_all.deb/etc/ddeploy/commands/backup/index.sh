sub_command="$base/commands/backup/subcommand/$1.sh"

help() {
    script_path=$(readlink -f "$0")
    script_directory=$(dirname "$script_path")
    cat $script_directory/_help
}

if [ -f "$sub_command" ]; then
    shift
    "$sub_command" "$@"
else
    help
fi

if [ $? -ne 0 ]; then
    help
fi
