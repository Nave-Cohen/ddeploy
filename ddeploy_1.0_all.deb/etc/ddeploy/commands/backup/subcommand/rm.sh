crontab -l | grep -vF '/etc/ddeploy/maintence/backup.sh $WORKDIR' | crontab -
return $?
