cron_backup() {
    local folder="$1"
    local every="$2"
    cronjob="@$every $base/maintence/backup.sh $folder "
    # Add the cron job commands to the crontab
    (
        crontab -l
        echo "$cronjob"
    ) | crontab -
}

if [ $# -lt 1 ] || ([[ "$1" != "daily" ]] && [[ "$1" != "weekly" ]]); then
    exit 1
fi

every="$1"
cron_backup "$WORKDIR" "$every"
